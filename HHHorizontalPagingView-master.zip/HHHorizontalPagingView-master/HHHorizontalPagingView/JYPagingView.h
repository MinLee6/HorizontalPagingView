//
//  JYPagingView.h
//  Demo
//
//  Created by weijingyun on 16/5/28.
//  Copyright © 2016年 weijingyun. All rights reserved.
//

#import "HHHorizontalPagingView.h"
#import "UIView+WhenTappedBlocks.h"

