//
//  ArtChangeNavViewController.h
//  Demo
//
//  Created by weijingyun on 2016/12/19.
//  Copyright © 2016年 weijingyun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ArtChangeNavViewController : UIViewController

@end
