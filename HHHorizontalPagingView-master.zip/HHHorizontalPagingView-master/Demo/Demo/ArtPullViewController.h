//
//  ArtPullViewController.h
//  Demo
//
//  Created by weijingyun on 16/10/21.
//  Copyright © 2016年 weijingyun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ArtPullViewController : UIViewController

@end
